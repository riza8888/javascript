/*
Buatlah sebuah function pushValidationn yang menerima 2 parameter
- arr bertipe data array of string yang merupakan kumpulan dari beberapa data string
- value merupakan data yang akan diinputkan ke dalam array

function akan menghasilkan sebuah data array baru dengan persyaratan sbb
- apabila isi value merupakan data string, maka value akan ditambahkan ke dalam array
- apabila isi value bukan data string, maka function mengembalikan array aslinya tanpa ditambahkan data apapun
*/


function pushValidation(arr, value) {
 if(typeof value === "string"){
    arr.push(value)

 }
 return arr
}

console.log(pushValidation(['a', 'b', 'c', 'd', 'e'], 'f')); // ['a', 'b', 'c', 'd', 'e', 'f']
console.log(pushValidation(['a', 'b', 'c', 'd', 'e'], 10)); // ['a', 'b', 'c', 'd', 'e']
console.log(pushValidation(['a', 'b', 'c', 'd', 'e'], false)); // ['a', 'b', 'c', 'd', 'e']
console.log(pushValidation(['a', 'b', 'c', 'd', 'e'], '160')); // ['a', 'b', 'c', 'd', 'e', '160']
