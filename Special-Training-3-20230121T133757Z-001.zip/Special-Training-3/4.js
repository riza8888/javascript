/*
Buatlah sebuah function findId yang mencari 1 data di array of object berdasrkan id nya
input function ini ada 2 parameter
- arr (data array of object)
- id (data number yang mempresentasikan id dari object yang akan dirubah)

output dari function ini ada array of object yang sudah berubah data salah 1 objectnya dengan syarat
- Apabila id ditemukan di data array, maka data dengan id yang dicari akan ditampilkan sebagai output
- apabila id tidak ditemukan maka tampilkan pesan `Id tidak ditemukan`
*/

function findId(arr, id) {
  let obj = {};
  let berhasil = false;
  for (let i = 0; i < arr.length; i++) {
    // console.log(arr[i]);
    // console.log(arr[i]["id"]);
    if (id === arr[i]["id"]) {
      berhasil = true;
      obj = arr[i];
      break;
    }
  }
  if (berhasil === true) {
    return obj;
  } else {
    return `Id tidak ditemukan`;
  }
}

let multiArr = [
  { id: 1, name: "Marco Tiger", age: 26 },
  { id: 2, name: "Acong Budiman", age: 52 },
  { id: 3, name: "Kris Evan", age: 36 },
  { id: 4, name: "Robert Downey", age: 46 },
];

console.log(findId(multiArr, 2));
//  { id: 2, name: 'Acing Wae', age: 52 }

let multiArr2 = [
  { id: 1, name: "Marco Tiger", age: 26 },
  { id: 2, name: "Acong Budiman", age: 52 },
  { id: 3, name: "Kris Evan", age: 36 },
  { id: 4, name: "Robert Downey", age: 46 },
];

console.log(findId(multiArr, 5));
// `Id tidak ditemukan`
