/*
Buatlah sebuah function groupingId yang mengelompokkan object berdasarkan id
input function ini ada 1 parameter
- arr (data array of object)

output dari function ini adalah object dengan 2 key 
- genap (list nama students dengan id genap)
- ganjil (list nama students dengan id ganjil)

*/


function groupingId(arr) {
    let output={genap:{list:[]},ganjil:{list:[]}}
    for (let i = 0; i < arr.length; i++) {
        let data = arr[i];
        let num=data.id
        // console.log(num);

        if(num%2!==0){

            output["ganjil"].list.push(data.name)
        }
        if(num%2===0){
            
            output["genap"].list.push(data.name)

        }
       
        
    }
   return output
}

let multiArr = [
    { id: 1, name: 'Marco Tiger', age: 26 },
    { id: 2, name: 'Acong Budiman', age: 52 },
    { id: 3, name: 'Kris Evan', age: 36 },
    { id: 4, name: 'Robert Downey', age: 46 },
    { id: 10, name: 'Lanu', age: 26 },
    { id: 12, name: 'Suki', age: 52 },
    { id: 23, name: 'Yamme', age: 36 },
    { id: 41, name: 'Yalle', age: 46 }
]

console.log(groupingId(multiArr)); 
// {
//     genap: {
//         list: [ 'Acong Budiman', 'Robert Downey', 'Lanu', 'Suki' ]
//     },
//     ganjil: {
//         list: [ 'Marco Tiger', 'Kris Evan', 'Yamme', 'Yalle']
//     }
// }

