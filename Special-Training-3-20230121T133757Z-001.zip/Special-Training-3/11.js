/*
Buatlah sebuah function filterArrayOfObjectByParams yang menmfilter data array of object
input function ini ada 2 parameter
- arr (data array of object)
- params (data array of string yang menjadi parameter pencarian)

output dari function ini ada array of object yang sudah terfilter dengan syarat
- data yang dihasilkan adalah data dari object yang namanya mengandung huruf yang terdapat di params
*/


function filterArrayOfObjectByParams(arr, params) {
    let output=[]
    let countO=0
    let countR=0
    for (let i = 0; i < arr.length; i++) {
        let data = arr[i];
        let nama=data.name
        for (let j = 0; j< nama.length; j++) {
        //   console.log(nama[j]);
      
            // console.log(params[0], nama[j]);
            if(params[0]===nama[j] ){
                // output.push(data)
                // console.log(data);
                countO++
                
            }
            else if(params[1]===nama[j] ){
                countR++
            }
           
           
        }
        // console.log(countO, countR);
         if(countO >=1 && countR >=1){
            output.push(data)
        }
        countO=0
        countR=0
        
    }
    
    return output
   
}

let multiArr = [
    { id: 1, name: 'Marco Tiger', age: 26 },
    { id: 2, name: 'Acong Budiman', age: 52 },
    { id: 3, name: 'Kris Evan', age: 36 },
    { id: 4, name: 'Robert Downey', age: 46 }
]

console.log(filterArrayOfObjectByParams(multiArr, ['o', 'r'])); 
// [
//     { id: 1, name: 'Marco Tiger', age: 26 },
//     { id: 4, name: 'Robert Downey', age: 46 }
// ]
