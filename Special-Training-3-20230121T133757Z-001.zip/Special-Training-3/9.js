/*
Buatlah sebuah function averageAge yang mencari rata-rata umur
input function ini ada 1 parameter
- arr (data array of object)

output dari function ini adalah number rata-rata umur dari semua orang yang ada
*/


function averageAge(arr) {
    let total=0
    let count=0
    for (let i = 0; i < arr.length; i++) {
        let data = arr[i];
        let umur=data.age
        total+=umur
        count++
        
    }

    total/=count

    return total
    
}

let multiArr = [
    { id: 1, name: 'Marco Tiger', age: 26 },
    { id: 2, name: 'Acong Budiman', age: 52 },
    { id: 3, name: 'Kris Evan', age: 36 },
    { id: 4, name: 'Robert Downey', age: 46 }
]

console.log(averageAge(multiArr)); 
// 40

