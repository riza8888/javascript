/*
Buatlah sebuah function pushData yang menerima 3 parameter
- arr bertipe data array 
- value merupakan data yang akan diinputkan ke dalam array
- index merupakan data number yang merupakan index tempat value diletakkan

function akan menghasilkan sebuah data array baru dengan persyaratan sbb
- apabila index lebih besar dari index terakhir data arr, maka value dimasukkan di akhir array
- apabila index lebih kecil dari 0, maka value dimasukkan di depan array (index ke 0)
- jika tidak termasuk ke dalam 2 kondisi di atas, maka value akan di masukkan sesuai index yang ditentukan
*/


function pushData(arr, value, index) {
    let data =[]
    if (index >= arr.length) {
        arr.push(value)
    } 
    if(index<0){
        index=0
    }
    for (let i = 0; i < arr.length; i++) {
        // console.log(arr[i]);
        if(index===i){
            data.push(value)
        } else{
            data.push(arr[i])
        }

        
    }
 
    return data
    
}

console.log(pushData(['a', 'b', 'c', 'd', 'e'], 'f', 3)); // ['a', 'b', 'c', 'f', 'd', 'e']
console.log(pushData(['a', 'b', 'c', 'd', 'e'], 10, 5)); // ['a', 'b', 'c', 'd', 'e', 10]
console.log(pushData(['a', 'b', 'c', 'd', 'e'], false, 2)); // ['a', 'b', false, 'c', 'd', 'e']
console.log(pushData(['a', 'b', 'c', 'd', 'e'], '160', -1)); // ['160', 'a', 'b', 'c', 'd', 'e']






