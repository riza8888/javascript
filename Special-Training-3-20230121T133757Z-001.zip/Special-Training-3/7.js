/*
Buatlah sebuah function filterArrayOfObject yang menmfilter data array of object
input function ini ada 2 parameter
- arr (data array of object)

output dari function ini ada array of object yang sudah terfilter dengan syarat
- data yang dihasilkan adalah data dari object yang lahir di tahun 1970 an
- asumsi tahun sekarang adalah tahun 2022
*/


function filterArrayOfObject(arr) {
    let batas1 = 2022-1979
    let batas2 = 2022-1970
   let output=[]
    for (let i = 0; i < arr.length; i++) {
        let data = arr[i];
        let umur = data.age
        // console.log(data);
        if (umur >=batas1 && umur <=batas2){
            output.push(data)
        }
        
    }
   return output
}

let multiArr = [
    { id: 1, name: 'Marco Tiger', age: 26 },
    { id: 2, name: 'Acong Budiman', age: 52 },
    { id: 3, name: 'Kris Evan', age: 36 },
    { id: 4, name: 'Robert Downey', age: 46 }
]

console.log(filterArrayOfObject(multiArr)); 
// [
//     { id: 2, name: 'Acong Budiman', age: 52 },
//     { id: 4, name: 'Robert Downey', age: 46 }
// ]
