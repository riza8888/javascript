/*
Buatlah sebuah function editArrayOfObject yang merubah salah 1 data array of object
input function ini ada 3 parameter
- arr (data array of object)
- input (data object baru yang akan menggantikan object yang lama)
- id (data number yang mempresentasikan id dari object yang akan dirubah)

output dari function ini ada array of object yang sudah berubah data salah 1 objectnya dengan syarat
- Apabila id ditemukan di data array, maka data dengan id yang dipilih akan dirubah
- apabila id tidak ditemukan maka tampilkan 'id tidak ditemukan'
*/


function editArrayOfObject(arr, input, id) {
    let output=[]
    let sama=0
   for (let i = 0; i < arr.length; i++) {
        let data = arr[i];
        // console.log(data);
        let num= data.id
        // console.log(num);
        if(num===id){
            output.push({id, name: input.name, age:input.age})
            sama++
        } else{
            output.push(data)
        }
       
   }
   if (sama===0){return `id tidak ditemukan`}

   return output
}

let multiArr = [
    { id: 1, name: 'Marco Tiger', age: 26 },
    { id: 2, name: 'Acong Budiman', age: 52 },
    { id: 3, name: 'Kris Evan', age: 36 },
    { id: 4, name: 'Robert Downey', age: 46 }
]

console.log(editArrayOfObject(multiArr, { name: 'Acing Wae', age: 52 }, 2)); 
// [
//     { id: 1, name: 'Marco Tiger', age: 26 },
//     { id: 2, name: 'Acing Wae', age: 52 },
//     { id: 3, name: 'Kris Evan', age: 36 },
//     { id: 4, name: 'Robert Downey', age: 46 }
// ]

let multiArr2 = [
    { id: 1, name: 'Marco Tiger', age: 26 },
    { id: 2, name: 'Acong Budiman', age: 52 },
    { id: 3, name: 'Kris Evan', age: 36 },
    { id: 4, name: 'Robert Downey', age: 46 }
]

console.log(editArrayOfObject(multiArr, { name: 'Acing Wae', age: 52 }, 5)); 
// 'id tidak ditemukan'

