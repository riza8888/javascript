/*
Buatlah sebuah function oldestPerson yang mencari person tertua berdasarkan umur
input function ini ada 1 parameter
- arr (data array of object)

output dari function ini adalah object dari 1 person dengan umur tertua
*/


function oldestPerson(arr) {
    let max=-Infinity
    let tua;
    for (let i = 0; i < arr.length; i++) {
        let data = arr[i];
        let umur=data.age
        // console.log(umur);
        if (umur>max){
            max=umur
            tua=data
        }
        
    }
   
    return tua
   
}

let multiArr = [
    { id: 1, name: 'Marco Tiger', age: 26 },
    { id: 2, name: 'Acong Budiman', age: 52 },
    { id: 3, name: 'Kris Evan', age: 36 },
    { id: 4, name: 'Robert Downey', age: 46 }
]

console.log(oldestPerson(multiArr)); 
// { id: 2, name: 'Acong Budiman', age: 52 }

