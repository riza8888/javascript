/*
Buatlah sebuah function generateArrayOfObject yang merubah data array multidimensi menjadi array of object

*/


function generateArrayOfObject(arr) {
    let output =[]

    for (let i = 0; i < arr.length; i++) {
        // console.log(arr[i]);
        let data= arr[i]
        // console.log(data[1],data[2]);
        let name = `${data[1]} ${data[2]}`
        let age= 2022- data[3]
        let id = data[0]
        let obj= {id, name, age}
        output.push(obj)

       
       
        // console.log(name);
    }

    return output
   
}

let multiArr = [
    [1, 'Marco', 'Tiger', 1996],
    [2, 'Acong', 'Budiman', 1970],
    [3, 'Kris', 'Evan', 1986],
    [4, 'Robert', 'Downey', 1976]
]

console.log(generateArrayOfObject(multiArr)); 
// [
//     { id: 1, name: 'Marco Tiger', age: 26 },
//     { id: 2, name: 'Acong Budiman', age: 52 },
//     { id: 3, name: 'Kris Evan', age: 36 },
//     { id: 4, name: 'Robert Downey', age: 46 }
// ]

