function getAnimals(arr) {
  let output = []
  // console.log(arr);
  let karnivora = []
  let herbivora = []
  let omnivora = []
  let temp = ""
  for (let i = 0; i < arr.length; i++) { //kupas array 1D
    let perHewan = arr[i];
    // console.log(perHewan);
    for (let j = 0; j < perHewan.length; j++) {
      let char = perHewan[j];
      // console.log(char, "=== ini huruf")
      if (char === ":") {
        // console.log(index);
        if (perHewan[j + 1] === "K") {
          karnivora.push(temp)
          temp = ""
          break;
          // console.log(char);
        } else if (perHewan[j + 1] === "H") {
          herbivora.push(temp)
          temp = ""
          break;
        } else if (perHewan[j + 1] === "O") {
          omnivora.push(temp)
          temp = ""
          break;
        }
      } else {
        temp += char
      }
    }
  }
  // console.log(karnivora);
 
  
  if (karnivora.length > 1) {
 
    if (karnivora[0].length > karnivora[1].length) {
      // karnivora = karnivora[0]
      output.push(karnivora[0])
    } else {
      // karnivora = karnivora[1]
      output.push(karnivora[1])
    }
    

  }

  // console.log(herbivora);
  // console.log(omnivora);
  if (herbivora.length > 1) {

    if (herbivora[0].length > herbivora[1].length) {
      // herbivora = herbivora[0]
      output.push(herbivora[0])
    } else {
      // herbivora = herbivora[1]
      output.push(herbivora[1])
    }

  }
  
  if (omnivora.length > 1) {

    if ( omnivora[0].length > omnivora[1].length) {
      // omnivora = omnivora[0]
      output.push(omnivora[0])
    } else {
      // omnivora = omnivora[1]
      output.push(omnivora[1])
    }
    // console.log(bestOmnivora);
  }

  // console.log(output);

  if (karnivora.length<=1 && herbivora.length<=1 && omnivora.length<=1 ){
       output.push(karnivora, herbivora, omnivora)
      let final =[]
      // console.log(output.length);
      for (let j = 0; j < output.length; j++) {
        let outputAlternatif = output[j]
        // console.log(outputAlternatif);
        for (let i = 0; i < outputAlternatif.length; i++) {
          // console.log(outputAlternatif[i]);
          final.push(outputAlternatif[i])
          // console.log(final);
          
        }
        
        
      }
      // console.log(final);
      return final

  }

  return output

}
//Test Case 

console.log(getAnimals(['Singa:K', 'Kuda:H', 'Monyet:O']))
// [ 'Singa','Kuda','Monyet' ]

console.log(getAnimals(['Macan:K', 'Ayam:O', 'Gajah:H', 'Monyet:O', 'Kerbau:H', 'Musang:O', 'Burung:H', 'Hiu:K']))
// // [ 'Macan', 'Kerbau', 'Monyet' ]

console.log(getAnimals(['Tikus:O', 'Merpati:H', 'Beruang:O', 'Elang:K', 'Perkutut:H', 'Harimau:K']))
//   // [ 'Harimau', 'Perkutut', 'Beruang' ]

  /*
  ['hewanJenisKarnivora', 'HewanJenisHerbivora', 'hewanJenisomnivora']
     yang dimasukin yang nawa hewan dengan huruf terbanyak
   */