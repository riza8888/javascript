function filterMovie(genres) {
  let movies = [
    ["Drama", "Boyhood", "The Last of the Mohicans", "The Goldfinch"],
    ["Action", "Mad Max", "The Batman", "Josh Wick"],
    ["Fantasy", "The Fall", "The Forbidden Kingdom", "Ladyhawke", "Sea Beast"],
    ["Comedy", "Safety Last", "The Trip"]
  ];
  // write your code here
  let userGenre = genres
  // console.log(userGenre);
  let drama = []
  let action = []
  let fantasy = []
  let comedy = []


  // akses pilihan genre user
  let userChoice = []
  let temp = ""

  for (let i = 0; i <= userGenre.length; i++) {
    let perGenre = userGenre[i];
      // console.log(perGenre);

    if (perGenre === ";" || perGenre === undefined) {
      userChoice.push(temp)
      temp = ""
    } else if (perGenre !== ";") {
      temp += perGenre
    }
    // console.log(userChoice);
    //  
  }
  // console.log(userChoice);


 let output= []

  // Memilih rekomendasi untuk user
  for (let j = 0; j < userChoice.length; j++) {
  let perChoice = userChoice[j];
  // console.log(perChoice);
  for (let k = 0; k < movies.length; k++) {
    let perMovie = movies[k];
    // console.log(perMovie[0]);
    if (perChoice === perMovie[0]) {
      output.push(perMovie)
      
    }
    
  }
  
}
  // console.log(output.length);
  if (output.length ===0) {
      return `Movie not found`
  }

  return output

}

function usersCanWatch(users) {
  if(typeof users !== "object"){
    return `Invalid Data!`
  }

  let recom = filterMovie(users.menu)
  return recom

}

// TEST CASE

// console.log(filterMovie([ "Action", "Drama", "Comedy" ]));
// console.log(filterMovie([ "Scifi", "Musical" ]));
const user1 = {
  name: "Bari",
  cinema: "XIV",
  menu: "Action;Drama;Comedy"
};
// console.log(usersCanWatch(user1));
/*
[
["Action", "Mad Max", "The Batman", "Josh Wick"],
["Drama", "Boyhood", "The Last of the Mohicans", "The Goldfinch"],
["Comedy", "Safety Last", "The Trip"]
]
*/

const user2 = {
  name: "Tole",
  cinema: "XIIX",
  menu: "Fantasy;Adventure;Comedy"
};
console.log(usersCanWatch(user2));
// /*
// [
//   ["Fantasy", "The Fall", "The Forbidden Kingdom", "Ladyhawke", "Sea Beast"],
//   ["Comedy", "Safety Last", "The Trip"]
// ]
// */

const user3 = {
  name: "Rizky",
  cinema: "Cinepolos",
  menu: "Scifi-Musical"
};
console.log(usersCanWatch(user3));
// // "Movie not found"

console.log(usersCanWatch());
// // "Invalid Data!"



  

