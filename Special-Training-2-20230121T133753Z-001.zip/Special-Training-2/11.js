function getPoints(history) {
    let itemPoint = {
      'Moonlight': 120,
      'Goldqueen': 550,
      'Beras Parist': 1200,
      'Minyak Fatma': 2500
    }
    // write your code here
  
    let belajaan = history.histories
    let beras = 0
    let moonlight = 0
    let goldqueen = 0
    let minyak = 0
    // console.log(beras);
    let userPoint = 0
    for (let i = 0; i < belajaan.length; i++) {
      let item = belajaan[i];
      // console.log(typeof item);
      if (item === "Moonlight") {
        userPoint += itemPoint.Moonlight
        moonlight++
      }
      if (item === "Goldqueen") {
        userPoint += itemPoint.Goldqueen
        goldqueen++
      }
      if (item === "Beras Parist") {
        userPoint += itemPoint["Beras Parist"]
        beras++
      }
      if (item === "Minyak Fatma") {
        userPoint += itemPoint["Minyak Fatma"]
        minyak++
      }
    }
    // console.log(userPoint);
    // console.log(moonlight, goldqueen, beras, minyak);
  
    let poin = {
      totalPoint: userPoint,
      belanjaanReport: {
        'Minyak Fatma': minyak,
        Moonlight: moonlight,
        'Beras Parist': beras,
        Goldqueen: goldqueen
      }
    }
    return poin
  }
  

  function getPrizes(points) {
    let listPrize = [
      [2000, 'Voucher 10k', 'Sticker', 'Penggaris'],
      [5000, 'Voucher 25k', 'Kinderboy', 'Tissue', 'Piring'],
      [10000, 'Payung', 'Panci']
    ]
    let jumlahPoint = getPoints(points)
    let userPoint = jumlahPoint.totalPoint
  
    // Push prize into prizes from the lowest prize tier
    let prizes = [];
    for (let i = 0; i < listPrize.length; i++) { // For every prize tier
      for (let j = 1; j < listPrize[i].length; j++) { // For every prize in that tier
        // console.log(listPrize[i][0]);
        if (userPoint >= listPrize[i][0]) { // If points is still more or equal to that tier's cost
          prizes.push(listPrize[i][j]); // Push a prize from that tier
          userPoint -= listPrize[i][0]; // Subtract tier cost from points
        }
        // console.log(userPoint,"====", prizes);
      }
    }
  
    // console.log(prizes);
    return prizes;
  }

function betamart(pembeli) {
    if(typeof pembeli !== "object"){
      return `Tidak ada pembeli yang belanja`
    }
    // write your code here
    let cekPoin = getPoints(pembeli)
    let userPrize = getPrizes(pembeli)
    // console.log(cekPoin.belanjaanReport);

    let output = {
      name: pembeli.name,
      belanjaanReport: cekPoin.belanjaanReport,
      prizes: userPrize
    }

    return output
}

console.log(
    betamart({
        name: 'Ilham',
        histories: [
            'Moonlight',
            'Goldqueen',
            'Beras Parist',
            'Moonlight',
            'Goldqueen',
            'Beras Parist',
            'Minyak Fatma',
            'Minyak Fatma',
            'Minyak Fatma',
            'Moonlight',
            'Goldqueen',
            'Goldqueen',
            'Moonlight',
            'Beras Parist',
            'Beras Parist',
            'Minyak Fatma',
            'Minyak Fatma',
            'Moonlight',
            'Moonlight'
        ]
    })
)

/*
{
  name: 'Ilham',
  belanjaanReport: { Moonlight: 6, Goldqueen: 4, 'Beras Parist': 4, 'Minyak Fatma': 5 },
  prizes: [ 'Voucher 10k', 'Sticker', 'Penggaris', 'Voucher 25k', 'Kinderboy' ]
}
*/

// console.log(
//     betamart({
//         name: 'Kosasih',
//         histories: [
//             'Moonlight',
//             'Moonlight',
//             'Goldqueen',
//             'Moonlight',
//             'Minyak Fatma',
//             'Goldqueen',
//             'Beras Parist',
//             'Beras Parist',
//             'Beras Parist',
//             'Moonlight',
//             'Minyak Fatma',
//             'Minyak Fatma',
//             'Moonlight',
//             'Goldqueen',
//             'Goldqueen',
//             'Goldqueen',
//             'Beras Parist',
//             'Moonlight',
//             'Moonlight',
//             'Beras Parist',
//             'Beras Parist',
//             'Minyak Fatma',
//             'Minyak Fatma',
//             'Goldqueen',
//             'Goldqueen',
//             'Moonlight',
//             'Moonlight',
//             'Moonlight',
//             'Moonlight'
//         ]
//     })
// )

/*
{
  name: 'Kosasih',
  belanjaanReport: { Moonlight: 11, Goldqueen: 7, 'Minyak Fatma': 5, 'Beras Parist': 6 },
  prizes: [
    'Voucher 10k',
    'Sticker',
    'Penggaris',
    'Voucher 25k',
    'Kinderboy',
    'Tissue'
  ]
}
*/

// console.log(betamart());
// Tidak ada pembeli yang belanja